# j2prompt-lint

A static, model-free linter for Jinja2 prompt templates. Use its command line,
Python API, or editor integrations to inspect variable contracts, chat markers,
instruction-context taint surfaces, token budgets, and formatting before a prompt
is sent to a model.

## Install

Requires Python 3.11 or newer. Download the wheel for the published version from
[Releases](https://github.com/center4aai/j2prompt-lint/releases), then install the
command in an isolated environment with [uv](https://docs.astral.sh/uv/):

```sh
uv tool install ./j2prompt_lint-0.1.0-py3-none-any.whl
j2prompt-lint --help
```

Once that version is available on the Python package index, run it without a
permanent tool installation:

```sh
uvx j2prompt-lint@0.1.0 examples/templates/clean.j2 --format json
```

Dependency installation can require a connection. Ordinary analysis runs locally
without a model inference call. The default reference tokenizer is bundled;
optional target-tokenizer integrations use local tokenizers or caches and
disclose a fallback or unavailable count.

## Quickstart

```sh
j2prompt-lint templates/
j2prompt-lint templates/ --format json
j2prompt-lint templates/ --format sarif > j2prompt-lint.sarif
j2prompt-lint templates/ --declare customer_name,customer_note --untrusted customer_note
j2prompt-lint templates/ --budget 4096
```

Inspect formatting changes before writing them:

```sh
j2prompt-lint templates/ --diff
j2prompt-lint templates/ --fix
```

`--diff` previews PFMT edits; `--fix` writes them. The options are mutually
exclusive. Review a diff because whitespace can change a rendered prompt.

## Checks

| Class | Conditions inspected |
|---|---|
| PVAR | Variable use against an explicit contract and supported definition flow. Contract inference and typo suggestions are opt-in. |
| PCHAT | Declared chat-format conditions for supported ChatML, Llama 3, Mistral, and Phi marker packs. Conversations are not rendered. |
| PINJ | Selected untrusted sources reaching recognized instruction contexts, with supported propagation, delimiters, and sanitizer filters. |
| PTOK | Static text against a token budget or context-window estimate, with tokenizer and approximation disclosures. |
| PFMT | Whitespace, blank lines, indentation, newlines, and Jinja delimiter layout, with supported fixes. |

PINJ flags template positions where untrusted variables reach instruction contexts
— an over-approximation of prompt-injection enabling patterns — and certifies
neither the presence nor the absence of an exploitable attack.

PINJ's default source model uses configured names and template annotations. With
no selected source, an empty diagnostic list supplies no security conclusion.
Inspect its check state as well as its diagnostics. The optional `undeclared`
source model seeds undeclared Jinja2 variables in addition to configured sources.

PCHAT includes coarse template-presence conditions and does not certify that
every rendered turn terminates correctly. PTOK's static counts and variable
estimates are not the complete token consumption of a rendered conversation or
an unconditional exact count for a target model.

## Configuration

Use `.j2prompt-lint.toml`, or `[tool.j2prompt-lint]` in `pyproject.toml`:

```toml
declared = ["customer_name", "customer_note"]
untrusted = ["customer_note"]
token_budget = 4096

[pinj]
source_model = "configured"
```

Contracts and sources can also be annotated in a template:

```jinja2
{# j2pl: vars(required=[customer_name, customer_note]) #}
{# j2pl: untrusted(customer_note) #}
Write a short reply to {{ customer_name }}.
<customer-note>{{ customer_note }}</customer-note>
```

Project settings are loaded first, then the optional `pinj-evaluation` profile,
then explicit CLI overrides. The profile selects undeclared-variable sources,
enables dynamic role loops, resets source/sanitizer lexicons, and selects a
reference-tokenizer context window of 8192, generation reserve 512, and
per-variable estimate 25. Inspect the resolved settings before using a profile:

```sh
j2prompt-lint --show-config
j2prompt-lint --profile pinj-evaluation --show-config
j2prompt-lint --explain PINJ
```

Unknown keys, unsupported settings, and invalid values are reported instead of
being silently accepted.

| Option | Purpose |
|---|---|
| `paths` | Files or directories containing templates. |
| `--format {text,json,sarif}` | Select diagnostic serialization. |
| `--fail-on {error,warning,info}` | Minimum failing severity; default `error`. |
| `--declare a,b` | Supply the PVAR variable contract. |
| `--untrusted a,b` | Select configured PINJ source names. |
| `--pinj-source-model {configured,undeclared}` | Select the PINJ source model. |
| `--pinj-dynamic-role-loops` / `--no-pinj-dynamic-role-loops` | Enable or override dynamic-role-loop analysis. |
| `--budget N` | Set the static token budget. |
| `--config PATH` | Load an explicit TOML configuration. |
| `--profile pinj-evaluation` | Apply the profile before explicit overrides. |
| `--show-config` | Print resolved JSON settings without linting. |
| `--explain {PVAR,PCHAT,PINJ,PTOK,PFMT}` | Print a rule class's scope statement. |
| `--diff` / `--fix` | Preview or apply supported PFMT edits. |
| `-h` / `--help` | Show command help. |

Exit `0` means the selected severity gate passes without a parse error; `1`
means a parse error or diagnostic meeting the gate; `2` means an invocation,
configuration, missing-input, or read/write error. An exit code describes the
configured run and is not a security certificate.

## Python API

Install the release wheel into your application's Python environment, for example
with `uv venv` followed by `uv pip install ./j2prompt_lint-0.1.0-py3-none-any.whl`.

```python
from pathlib import Path

from j2prompt_lint.core.config import LintConfig
from j2prompt_lint.core.engine import lint_path, lint_text

config = LintConfig(
    declared_vars=frozenset({"customer_name"}),
    token_budget=2048,
)
result = lint_text("greeting.j2", "Hello {{ customer_name }}.\n", config)

if result.parse_error is not None:
    print(result.parse_error)
for diagnostic in result.diagnostics:
    print(diagnostic.line, diagnostic.col, diagnostic.code, diagnostic.message)
print("PINJ check state:", result.pinj_check_state.value)

files = lint_path([Path("templates")], config)
```

`lint_text(file, source, config)` returns a `FileResult` containing diagnostics,
an optional parse error, and PINJ's check state. `lint_path(paths, config)` adds
discovery and reading. Diagnostic positions are 1-based; some AST-derived
findings use column 1 when a precise column is unavailable.

## Six examples

The included templates demonstrate individual rule concerns and a small example
with no intended structural violation. Run these commands from the repository
root. Project settings and explicit overrides determine the findings.

| Template | Try it |
|---|---|
| [clean.j2](examples/templates/clean.j2) | `j2prompt-lint examples/templates/clean.j2 --format json` |
| [pvar_contract.j2](examples/templates/pvar_contract.j2) | `j2prompt-lint examples/templates/pvar_contract.j2` |
| [pchat_missing_eot.j2](examples/templates/pchat_missing_eot.j2) | `j2prompt-lint examples/templates/pchat_missing_eot.j2` |
| [pinj_taint.j2](examples/templates/pinj_taint.j2) | `j2prompt-lint examples/templates/pinj_taint.j2 --untrusted customer_note --fail-on warning` |
| [ptok_budget.j2](examples/templates/ptok_budget.j2) | `j2prompt-lint examples/templates/ptok_budget.j2 --budget 24` |
| [pfmt_layout.j2](examples/templates/pfmt_layout.j2) | `j2prompt-lint examples/templates/pfmt_layout.j2 --diff` |

## Editors and automation

The included [VS Code client](editors/vscode/) runs the CLI with JSON output when
a template is saved. Set `j2promptLint.path` to the installed executable if it is
not on the editor's PATH. The client and Python tool are separate installations.

For an LSP-capable editor, configure `j2prompt-lint-lsp` as a stdio language server.
It publishes open-buffer diagnostics and supplies supported quick fixes. The
included VS Code client uses the on-save CLI route rather than the LSP route.

The [pre-commit example](examples/precommit-integration/) uses hook ID
`j2prompt-lint`; pin a published release tag or commit in your consumer
configuration. [The SARIF example](examples/github-code-scanning.yml) installs a
versioned wheel, checks its SHA256, and uploads diagnostics in a manual GitHub
Actions job. Set its input path, version, and wheel hash. Diagnostic exit code 1
still permits that example to upload SARIF; invocation errors stop it.

## Tool scope and prior work

1. **Static prompt linting is prior art.** [PromptSet](https://doi.org/10.1145/3643795.3648395)
   introduced the concept and spelling/whitespace surface passes on
   Python-extracted prompt strings. This tool combines static classes on Jinja2
   templates.
2. **Model judging and repair are prior art.**
   [PromptDoctor](https://doi.org/10.1109/ESEM64174.2025.00067) and
   [Microsoft Chat Customizations Evaluations](https://marketplace.visualstudio.com/items?itemName=ms-vscode.vscode-chat-customizations-evaluations)
   use LLM judging. PromptDoctor also executes attacks and applies LLM repair.
   Those capabilities complement static template analysis.
3. **PINJ follows information-flow and taint-analysis practice.** It identifies
   bounded taint surfaces under a selected source model. It is not an
   inference-time attack detector or prompt-injection defense.
4. **The classes are operational categories.** They align with
   [Tian and colleagues' taxonomy](https://arxiv.org/abs/2509.14404) and are not a
   comprehensive new taxonomy of prompt defects.
5. **Structural checks do not establish semantic quality.** They do not resolve
   contradiction, ambiguity, persona consistency, or intent-coverage gaps, or
   guarantee intended model behavior.
6. **Variable contracts and message validation are prior art.** Jinja2 variable
   extraction and framework checks, including LangChain, Haystack, banks,
   promptflow and promptkit-core, predate this tool. Existing tools check
   undeclared and, in some cases, declared-but-unused variables. Frameworks also
   validate their own message tags or lists. PVAR contributes its contracts and
   its place in the combined workflow.
7. **Template supply-chain analysis is prior art.** glyphhound, c4nary, and
   chatpin perform render-free audits on the Jinja2 AST. c4nary propagates
   template taint and detects planted instructions. These tools address
   malicious templates; PINJ examines untrusted values under a trusted template.
8. **Region-aware injection taint analysis is prior art.** CodeQL provides
   region-aware prompt-injection taint analysis in host code. TaintP2X and
   agentic-guard also analyze host code. PINJ applies source, sink, and sanitizer
   reasoning within the template.
9. **Chat-format conformance checking is prior art.**
   [ChatLint](https://github.com/dimondevceo/ChatLint) checks rendered conversations;
   [gguf-template-doctor](https://github.com/N-Combinator/gguf-template-doctor)
   uses a static scanner. PCHAT applies declared chat-format conditions on the
   Jinja2 AST; no claim of firstness is made.

PINJ flags template positions where untrusted variables reach instruction contexts
— an over-approximation of prompt-injection enabling patterns — and certifies
neither the presence nor the absence of an exploitable attack.

## License and citation

The software is licensed under [Apache-2.0](LICENSE). Its software citation is
provided in [CITATION.cff](CITATION.cff).
